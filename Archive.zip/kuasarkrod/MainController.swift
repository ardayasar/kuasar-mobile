//
//  MainController.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import SwiftUI

struct MainController: View {
    
    @AppStorage("signedIn") var signInSuccess: Bool = false
    @AppStorage("passwordCreation") var passwordCreated: Bool = false
    
    var body: some View {
        return Group {
            if signInSuccess {
                HomePage()
            }
            else if passwordCreated{
                
            }
            else {
                Login()
            }
        }
    }
}
