//
//  PushNotificationDelegate.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import UIKit
import UserNotifications
import PushKit

class PushNotificationDelegate: UIResponder, UIApplicationDelegate{
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        print("Application run completed succesfully")
        registerPushNotifications()
        return true
    }
    
    func registerPushNotifications(){
        UNUserNotificationCenter.current().delegate = self
        let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
        
        UNUserNotificationCenter.current()
            .requestAuthorization(options: authOptions) { granted, error in
                print("Is Permission Granted: \(granted)")
                
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                }
                else{
                    DispatchQueue.main.async{
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                }
            }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        print("Succesfully registered notification")
        let tokenParts = deviceToken.map{data in String(format: "%02.2hhx", data)}
        let token = tokenParts.joined()
        print(token)
        sendNotificationUUID_toServer(UUID: token)
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Failed to register notification")
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        print("didReceiveRemoteNotification")
        print(userInfo)
    
    }
    
    func sendNotificationUUID_toServer(UUID: String) {
            guard let url = URL(string: "https://kuasar-mobile-dev.ardayasar.com/alert/introduce?data=" + UUID) else {
                print("Invalid URL")
                return
            }

            var request = URLRequest(url: url)
            request.httpMethod = "GET"

            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    return
                }

                if let httpResponse = response as? HTTPURLResponse {
                    print("Status code: \(httpResponse.statusCode)")
                }

                if let data = data, let responseString = String(data: data, encoding: .utf8) {
                    print("Response data: \(responseString)")
                }
            }
            task.resume()
        }
    
}

extension PushNotificationDelegate: UNUserNotificationCenterDelegate{
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("UserNotificationCenter  didReceive")
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("userNotificationCenter willPresent")
        completionHandler(UNNotificationPresentationOptions(rawValue: 0))
    }
}
