//
//  HomePage.swift
//  AnimeGlobe.net
//
//  Created by Arda Yasar on 14.02.2023.
//

import SwiftUI

struct HomePage: View {
    var body: some View {
        TabView{
            Home()
                .tabItem{
                    Label("Anasayfa", systemImage: "house")
                }
            Baston()
                .tabItem{
                    Label("Bastonum", systemImage: "light.min")
                }
            Profile()
                .tabItem{
                    Label("Profil", systemImage: "person.crop.circle")
                }
        }
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
