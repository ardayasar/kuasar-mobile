//
//  Baston.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import SwiftUI

struct Baston: View {
    @State private var distance: Double = 1.0 // Mesafe (metre olarak)
    @State private var isVibrating: Bool = false
    @State private var vibrationIntensity: Double = 0.5 // 0.0 (Yumuşak) ile 1.0 (Sert) arasında
    @State private var lastSeenItems: [String] = ["Engel: 1.5 metre", "Kedi: 0.8 metre", "Araba: 6.0 metre"]
    @State private var batteryLevel: Double = 100 // Pil yüzdesi
    @State private var thresholdDistance: Double = 2.0 // Bildirim için mesafe eşiği (metre olarak)
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Mesafe Bilgisi")) {
                    Text("Mesafe: \(String(format: "%.2f", distance)) metre")
                        .font(.headline)
                    
                    ZStack(alignment: .leading) {
                        Rectangle()
                            .frame(height: 30)
                            .foregroundColor(.gray)
                        
                        Rectangle()
                            .frame(width: min(300, CGFloat(300 * (1 - distance / 10))), height: 30)
                            .foregroundColor(distance < thresholdDistance ? .red : (distance < 5 ? .yellow : .green))
                    }
                    .cornerRadius(15)
                    .padding(.vertical)
                    
                    if isVibrating {
                        Text("Titreşim!")
                            .font(.subheadline)
                            .foregroundColor(.red)
                    }
                }
                
                Section(header: Text("Titreşim Kontrolü")) {
                    HStack {
                        Text("Şiddet")
                        Slider(value: $vibrationIntensity, in: 0...1)
                    }
                }
                
                Section(header: Text("Bildirim Mesafe Eşiği")) {
                    HStack {
                        Text("Eşik")
                        Slider(value: $thresholdDistance, in: 0...10, step: 0.1)
                        Text("\(String(format: "%.1f", thresholdDistance)) metre")
                            .foregroundColor(.gray)
                    }
                }
                
                Section(header: Text("Son Görülen Nesneler")) {
                    ForEach(lastSeenItems, id: \.self) { item in
                        Text(item)
                    }
                }
                
                Section(header: Text("Pil Durumu")) {
                    HStack {
                        Text("Pil Seviyesi")
                        Spacer()
                        Text("\(String(format: "%.0f", batteryLevel))%")
                    }
                    ProgressView(value: batteryLevel, total: 100)
                        .progressViewStyle(LinearProgressViewStyle())
                        .frame(height: 10)
                }
                
                Section {
                    Button(action: {
                        // Mesafe değişimini simüle et
                        distance = Double.random(in: 0...10)
                        // Titreşim mantığını simüle et
                        isVibrating = distance < thresholdDistance
                        // Son görülen nesneye yeni bir öğe ekle
                        lastSeenItems.append("Engel: \(String(format: "%.2f", distance)) metre")
                        // Pil tüketimini simüle et
                        batteryLevel -= Double.random(in: 0...5)
                        if batteryLevel < 0 { batteryLevel = 0 }
                    }) {
                        Text("Mesafe Değişimini Simüle Et")
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                }
            }
            .navigationTitle("Baston Ayarları")
        }
    }
}

struct Baston_Previews: PreviewProvider {
    static var previews: some View {
        Baston()
    }
}
