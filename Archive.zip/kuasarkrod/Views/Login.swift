//
//  Login.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import SwiftUI

struct Login: View {
    @State private var userName: String = ""
    @State private var password: String = ""
    
    @State private var showError = false
    
    @AppStorage("signedIn") var signInSuccess: Bool = false
    
    var body: some View {
        VStack {
//            Spacer().frame(width: 100)
            Image("login-icon")
                .resizable()
                .frame(width: 208, height: 100)
                .scaledToFit()
            TextField("E-posta", text: $userName)
                .padding(.horizontal)
                .frame(width: 300, height: 40)
                .overlay(RoundedRectangle(cornerRadius: 5)
                            .stroke(lineWidth: 1)
                            .opacity(0.5)
                )
                .keyboardType(.emailAddress)
                .textInputAutocapitalization(.never)
            
            SecureField("Şifre", text: $password)
                .padding(.horizontal)
                .frame(width: 300, height: 40)
                .overlay(RoundedRectangle(cornerRadius: 5)
                            .stroke(lineWidth: 1)
                            .opacity(0.5)
                )
            
            Spacer().frame(height: 5)
            
            AsyncButton(action: {
                self.signInSuccess = true
                
            }) {
                Text("Giriş Yap")
                    .foregroundColor(Color.white)
                    .frame(width: 300, height: 40)
                    .background(LinearGradient(gradient: Gradient(colors: [Color("Button Background Color"), Color("Button Background Color")]), startPoint: .top, endPoint: .bottom))
                    .cornerRadius(8)
            }
            .padding()
            
            if showError {
                Text("Hatalı e-posta/şifre").foregroundColor(Color.red)
            }
            
//            Button(action: {
//
//            }){
//                Text("Şifremi Unuttum")
//                    .foregroundColor(Color("ForgotPassword"))
//                    .frame(width: 290, alignment: .leading)
//                    .font(.system(size: 16))
////                    .multilineTextAlignment(.center)
//            }
            
            Spacer()
                .frame(height: 10)
            
            HStack{
                Divider()
                    .frame(width: 100, height: 1)
                    .overlay(.white)
                    .opacity(0.6)
                Text("Veya")
                    .frame(width: 50, height: 50)
                    .foregroundColor(Color.white)
                    .opacity(0.6)
                Divider()
                    .frame(width: 100, height: 1)
                    .overlay(.white)
                    .opacity(0.6)
            }
            
            Button(action: {
                //Action to register
            }) {
                Label("E-posta ile üye ol", systemImage: "envelope")
                    .foregroundColor(Color.white)
                    .frame(width: 300, height: 40)
                    .overlay(RoundedRectangle(cornerRadius: 5)
                        .stroke(Color.white, lineWidth: 1)
                        .opacity(0.7)
                    )
            }
            .padding()
            
        }
    }
}


struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
            .preferredColorScheme(.dark)
    }
}


extension View {
    func getRootViewController() -> UIViewController{
        guard let screen = UIApplication.shared.connectedScenes.first as? UIWindowScene else{
            return .init()
        }
        
        guard let root = screen.windows.first?.rootViewController else {
            return .init()
        }
        
        return root
    }
}
