//
//  Profile.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import SwiftUI

struct EmergencyContact {
    var name: String
    var phoneNumber: String
}

struct Profile: View {
    @State private var name = ""
    @State private var age = ""
    @State private var phoneNumber = ""
    @State private var bloodType = ""
    @State private var emergencyContacts: [EmergencyContact] = []
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Kişisel Bilgiler")) {
                    TextField("İsim", text: $name)
                    TextField("Yaş", text: $age)
                        .keyboardType(.numberPad)
                    TextField("Telefon Numarası", text: $phoneNumber)
                        .keyboardType(.phonePad)
                    TextField("Kan Grubu", text: $bloodType)
                }
                
                Section(header: Text("Acil Durum Kişileri")) {
                    ForEach(emergencyContacts.indices, id: \.self) { index in
                        EmergencyContactRow(emergencyContact: self.$emergencyContacts[index])
                    }
                    
                    Button(action: {
                        self.emergencyContacts.append(EmergencyContact(name: "", phoneNumber: ""))
                    }) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Acil Durum Kişisi Ekle")
                        }
                    }
                }
            }
            .navigationBarTitle("Profil")
        }
    }
}

struct EmergencyContactRow: View {
    @Binding var emergencyContact: EmergencyContact
    
    var body: some View {
        HStack {
            TextField("İsim", text: $emergencyContact.name)
            TextField("Telefon Numarası", text: $emergencyContact.phoneNumber)
                .keyboardType(.phonePad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.trailing)
                .onTapGesture {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                }
        }
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
