//
//  Home.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import SwiftUI

struct Home: View {
    var body: some View {
        VStack{
            Button {
                sendAlertRequest()
            } label: {
                Text("Acil Yardım")
                    .frame(width: UIScreen.main.bounds.width * 0.9, height: 80)
                    .background(Color.red)
                    .foregroundStyle(.white)
                    .font(.system(size: 28))
            }

        }
        .padding()
    }
    
    func sendAlertRequest() {
            guard let url = URL(string: "https://kuasar-mobile-dev.ardayasar.com/alert") else {
                print("Invalid URL")
                return
            }

            var request = URLRequest(url: url)
            request.httpMethod = "GET"

            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                    return
                }

                if let httpResponse = response as? HTTPURLResponse {
                    print("Status code: \(httpResponse.statusCode)")
                }

                if let data = data, let responseString = String(data: data, encoding: .utf8) {
                    print("Response data: \(responseString)")
                }
            }
            task.resume()
        }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
