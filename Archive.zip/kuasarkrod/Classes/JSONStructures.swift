import Foundation

// MARK: - UserLogin Data Input

struct userData: Codable {
    let email, password: String
}

// MARK: - UserLogin Accept JSON
struct userLogin: Codable {
    let createPassword: Bool
    let accepted: Bool
    let loginInformation: LoginInformation
    let error: Error
}

struct Error: Codable {
    let errCode: Int
    let errMsg: String
}

struct movie: Codable {
    let id: Int
    let name: String
    let url: String
}

struct LoginInformation: Codable {
    let sessionID, authKey, userName, userPhoto: String

    enum CodingKeys: String, CodingKey {
        case sessionID, authKey
        case userName = "user_name"
        case userPhoto = "user_photo"
    }
}
