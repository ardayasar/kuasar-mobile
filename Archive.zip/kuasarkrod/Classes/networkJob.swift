//
//  networkJob.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import Foundation

var loginUrl: URL = URL(string: "http://localhost:1604/api/login")!
let encoder = JSONEncoder()

class networkJobs {
    init() {
        print("networkJobs clsss loaded")
    }
    
    func login(email: String, password: String, loginType: String) async -> Bool {
        var request = URLRequest(url: loginUrl)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        
        
        let userdata = userData(email: email, password: password)
        do {
            let sendingData = try encoder.encode(userdata)
            let (data, _) = try await URLSession.shared.upload(for: request, from: sendingData)
            let decodedUserInfo = try JSONDecoder().decode(userLogin.self, from: data)
            print(decodedUserInfo)
            if(decodedUserInfo.accepted == true){
                if(decodedUserInfo.createPassword == true){
                    UserDefaults.standard.set(true, forKey: "passwordCreation")
                }
                return true
            }
            else{
                return false
            }
        } catch {
            print("Checkout failed.")
            return false
        }
    }
}
