//
//  notificationManager.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 19.05.2024.
//

import Foundation
import NotificationCenter

class NotificationManager: NSObject, ObservableObject{
    override init(){
        super.init()
        self.registerForNotification()
    }
    
    func registerForNotification() {
        UIApplication.shared.registerForRemoteNotifications()
        
        let center : UNUserNotificationCenter = UNUserNotificationCenter.current()
        
        center.requestAuthorization(options: [.sound , .alert , .badge ], completionHandler: { (granted, error) in
            if ((error != nil)) { UIApplication.shared.registerForRemoteNotifications() }
            else {
                print("Notifications not registered")
            }
        })
    }
}
