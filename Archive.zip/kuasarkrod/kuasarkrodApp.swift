//
//  kuasarkrodApp.swift
//  kuasarkrod
//
//  Created by Arda Yasar on 18.05.2024.
//

import SwiftUI

@main
struct kuasarkrodApp: App {
    @UIApplicationDelegateAdaptor private var notificationDelegate: PushNotificationDelegate
    var body: some Scene {
        WindowGroup {
            MainController()
        }
    }
}
